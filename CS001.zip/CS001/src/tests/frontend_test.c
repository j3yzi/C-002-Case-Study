// ## HOW TO COMPILE ##
// Use the compile_frontend_test.bat or compile_frontend_test.sh script

#include <stdio.h>
#include <stdlib.h>
#include "../../include/employee.h"

EmployeeNode* empHead = NULL;
EmployeeNode* empCurr = NULL;
EmployeeNode* empTail = NULL;

int main(void) {
    printf("=== Frontend Test START ===\n");
    
    // Test functions here
    
    printf("\n=== Frontend Test COMPLETE ===\n");
    return 0;
}