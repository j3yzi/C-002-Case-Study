// ## HOW TO COMPILE ##
// Use the compile_backend_test.bat or compile_backend_test.sh script

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "../../include/employee.h"

EmployeeNode *head = NULL;
EmployeeNode *mid = NULL;
EmployeeNode *tail = NULL;
const char* dataFile = "../../data/record_test.bin";

int main(void)
{    
    printf("=== Backend Test START ===\n");
    
    // Test functions here
    
    printf("\n=== Backend Test COMPLETE ===\n");
    
    return 0;
}
