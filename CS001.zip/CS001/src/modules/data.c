#include "../../include/employee.h"
#include "../../include/list.h"

int exportEmployeeDataToFile(list* employeeList, const char *filename) {

}

list* loadEmployeeDataFromFile(const char* filename, ListType listType) {
    
}
